//
//  OperationView.h
//  OperationsManufacturing
//
//  Created by Dylan Sturgeon on 5/16/15.
//  Copyright (c) 2015 dylansturg. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OperationView : UIView

@property (nonatomic, copy) NSString *productName;

@end
