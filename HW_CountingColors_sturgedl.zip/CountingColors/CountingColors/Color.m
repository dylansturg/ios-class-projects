//
//  Color.m
//  CountingColors
//
//  Created by Dylan Sturgeon on 3/20/15.
//  Copyright (c) 2015 dylansturg. All rights reserved.
//

#import "Color.h"


@implementation Color

@dynamic name;
@dynamic pressedCount;
@dynamic sessionPressedCount;

@end
