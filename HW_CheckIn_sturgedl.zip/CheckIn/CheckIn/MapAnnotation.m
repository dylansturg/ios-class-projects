//
//  MapAnnotation.m
//  CheckIn
//
//  Created by Dylan Sturgeon on 5/1/15.
//  Copyright (c) 2015 dylansturg. All rights reserved.
//

#import "MapAnnotation.h"

@implementation MapAnnotation

@end
