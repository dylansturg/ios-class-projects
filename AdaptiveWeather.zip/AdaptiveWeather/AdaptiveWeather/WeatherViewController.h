//
//  ViewController.h
//  AdaptiveWeather
//
//  Created by Dylan Sturgeon on 4/14/15.
//  Copyright (c) 2015 dylansturg. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WeatherViewController : UIViewController <UITableViewDataSource, UITableViewDelegate>


@end

