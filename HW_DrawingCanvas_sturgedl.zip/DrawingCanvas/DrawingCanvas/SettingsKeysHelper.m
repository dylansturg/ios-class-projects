//
//  SettingsKeysHelper.m
//  DrawingCanvas
//
//  Created by Dylan Sturgeon on 4/21/15.
//  Copyright (c) 2015 dylansturg. All rights reserved.
//

#import "SettingsKeysHelper.h"

@implementation SettingsKeysHelper

+(NSString *)ShapeFillColor{
    return @"ShapeFillColor";
}

+(NSString *)ShapeCornerRadius{
    return @"ShapeCornerRadius";
}

@end
